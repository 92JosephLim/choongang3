import { Link } from "react-router-dom";
import ContentImg_1 from '../../img/contentImg_1.png';
import ContentImg_2 from '../../img/contentImg_2.png';

const TypeContents = () => {
    return(
        // <BasicLayout>
            <div id="contentSection" className="text-3xl grid grid-cols-2 bg-[#FFFFFF] mb-10">
                <div id="contentImg " className="grid ml-20 mr-5 mb-10">
                    <img src={ContentImg_1} className="h-80" />
                </div>

                <div id="contentImg " className="grid mr-20 ml-5 mb-10">
                    <img src={ContentImg_2} className="h-80" />
                </div>
            </div>
        // </BasicLayout>
    );
}
export default TypeContents;