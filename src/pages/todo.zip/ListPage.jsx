//#3. 목록데이터 가져오기 ()
import ListComponent from "../../components/todo/ListComponent";

const ListPage = () => {

  return ( 
        <div className="p-4 w-full  bg-lime-700">
            <div className="text-3xl font-extrabold">
                Todo 리스트 페이지(List Page) Component 
            </div> 
            <ListComponent />

        </div>
   );
}
 
export default ListPage;
