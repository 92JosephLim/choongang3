import { Link } from "react-router-dom";
import pepe from '../../img/pepe.png';
import sunny from '../../img/sunny.svg';
import rainy from '../../img/rainy.svg';
import foggy from '../../img/foggy.svg';


const SevenDaysWeather = () => {
    return(
        // <BasicLayout>

        
            <div id="contentSection" className="text-3xl flex grid-cols-2 bg-[#FFFFFF] mb-10">
   
   <div id="Mon" className="ml-7 mr-5 mb-5">
   <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>월요일</p>  
    
    <img src={sunny} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 22° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 11° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 33% </p>  
</div>

    <div id="Tue" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>화요일</p>  

    <img src={rainy} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 24° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 14° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 48% </p>  

    </div>

    <div id="Wes" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>수요일</p>  

    <img src={foggy} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 22° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 11° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 38% </p>  

    </div>

    <div id="Thr" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>목요일</p>  

    <img src={foggy} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 22° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 11° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 26% </p>  
    </div>

    <div id="Fri" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>금요일</p>  

    <img src={sunny} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 25° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 13° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 45% </p>  
    </div>

    <div id="Sat" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>토요일</p>  

    <img src={foggy} className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 23° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 10° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 65% </p>
    </div>

    <div id="Sun" className=" ml-5 mr-5 mb-5">
    <p className="text-sm text-black" style={{color: "black", fontSize: "13px"}}>일요일</p>  

    <img src={rainy} alt="Sun" className="h-20" />
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최고: 22° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>최저: 11° </p>  
    <p className="text-sm text-black" style={{color: "black", fontSize: "10px"}}>습도: 38% </p>    </div>
            </div>

            
        // </BasicLayout>
    );
}
export default SevenDaysWeather;